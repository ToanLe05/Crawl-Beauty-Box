import collections,copy,gzip,json,pathlib,re,unicodedata
from lxml import html

B=pathlib.Path('/tmp/beautybox_enrich_4428')
rows=json.loads((B/'rows.json').read_text());original=copy.deepcopy(rows)
raw=json.loads((B/'raw.json').read_text())
old={r['id']:r['data'] for r in raw if r['source']=='Chi tiết sản phẩm'}
catalog={r['id']:r['data'] for r in raw if r['source']=='Sản phẩm trong catalog'}
live={}
for p in (B/'live').glob('*.json.gz'):
 d=json.loads(gzip.decompress(p.read_bytes()))
 if d.get('status')=='ok':live[d['product_id']]=d
def norm(s):
 s=unicodedata.normalize('NFKD',str(s or '').lower()).replace('đ','d')
 s=''.join(c for c in s if not unicodedata.combining(c))
 return re.sub(r'[^a-z0-9]+',' ',s).strip()
def text_html(markup):
 tree=html.fragment_fromstring(markup or '<p></p>',create_parent='div')
 for x in tree.xpath('.//script|.//style|.//noscript'):x.drop_tree()
 for x in tree.xpath('.//br'):x.tail='\n'+(x.tail or '')
 for x in tree.xpath('.//p|.//li|.//div|.//h1|.//h2|.//h3|.//h4|.//tr'):
  x.tail='\n'+(x.tail or '')
 for x in tree.xpath('.//td|.//th'):x.tail=': '+(x.tail or '')
 return '\n'.join(re.sub(r'\s+',' ',x).strip(' \t\xa0') for x in tree.text_content().splitlines() if x.strip())
def detail(p):
 ds=(p or {}).get('detail') or []
 return next((d for d in ds if d.get('langCode')=='vi'),ds[0] if ds else {})
def flatten_attrs(x):
 if isinstance(x,list):
  for y in x:yield from flatten_attrs(y)
 elif isinstance(x,dict) and x.get('attributeId'):
  yield x
def attribute_text(a):return str(detail(a).get('name') or a.get('value') or '').strip()
def unique(xs):return list(dict.fromkeys(x for x in xs if x))
def sizes(s,counts=False):
 units=r'ml|kg|g|l'+(r'|miếng|mieng|pcs|pieces' if counts else '')
 found=[]
 for n,u in re.findall(r'(?<![\w.])(\d+(?:[.,]\d+)?)\s*('+units+r')\b',s or '',re.I):
  if float(n.replace(',','.'))<=0:continue
  u=u.lower();u={'mieng':'miếng','pieces':'pcs'}.get(u,u)
  found.append(n.replace(',','.')+' '+u)
 return unique(found)

ALIASES={}
def add_brand(canonical,*aliases):
 for alias in (canonical,)+aliases:
  if norm(alias):ALIASES[norm(alias)]=canonical
for r in rows:
 if r.get('F'):add_brand(r['F'])
for name in ['Lily Bell','GLXY','Jomi','Silcot','Maybelline','Romand','Colorkey','Innisfree','Lemonade','M.O.I','BOM','Carslan','Vacosi','Nuxe','Lipit','&honey','Moremo','Dcash','Aromatica','Vichy',"L'Oreal Paris",'Adolph','Ollin','Weilaiya','Clear','Olaplex','Shu Uemura','Naris','Nara','Yves Rocher','Tangle Teezer',"Tesori D'Oriente",'Vipo','numbuzin','CeraVe','Klairs','Mude',"Momo's Workshop",'Lanbena','BIAIfekt','Laneige','Torriden','Banila Co','B.By Banila','Marc Jacobs','Ralph Lauren','Laura Anne','Versace','D Program','Decorté','Skin1004',"D'Alba",'Round Lab','Colorescience','Bbia','Glamrr Q','Supernova','Murad','Green Pharmacy','Lux','Anessa','Exclusive Cosmetic','Pure Paw Paw','Roger & Gallet','Byvibes Wonder Bath','Belif',"L'Occitane",'Fixderma','Bioré','Alltimate','ZO&FRIENDS','Laka','ma:nyo','Mediheal','Dr.G','Cetaphil','Eucerin','Hada Labo','Hatomugi','Kosé','Senka','Some By Mi','Neogen','Jumiso','Isntree','Tocobo','Tree Hut','Bath & Body Works','Heimish','9wishes','Kiss Me','K-Palette','The Saem','DHC','Curel','Kracie','Tsubaki','Fino','Kundal','YOLU','TRESemmé','Dove','Selsun','Head & Shoulders','BTSO','Reihaku','W.Dressroom','Moschino','Guess','Calvin Klein','Burberry','Issey Miyake','Davidoff','Montblanc','Carolina Herrera','Lacoste','Clinique','MAC','Chanel','Dior','Lancôme','Sulwhasoo','Shiseido','Estée Lauder','Dr.Ceuracle','Dr.Jart+','Abib','AXIS-Y','VT','Eqqualberry','Tocobo','UNOVE','Unleashia','Dasique','Fwee','Hince','Espoir','Wakemake','The Lab By Blanc Doux','Lovito','Lifebuoy','On The Body','Daisy Doll','Saborino','Simple','Himalaya','Real Techniques','Miniso','Kemei','Benton','Caryophy','Acnes','Mentholatum','Foellie','Jo Malone','BareSoul','Herbario','Milaganics','Reuzel']:
 add_brand(name)
add_brand('THE FACE SHOP','THEFACESHOP');add_brand('MISE EN SCENE','Mise En Scène','Mise-en-scène');add_brand('CLIO','Clio Professional');add_brand('PERIPERA');add_brand('DERMATORY')
add_brand('BIAIfekt','BIAI Fekt');add_brand("L'Oreal Paris",'Loreal Paris','L’Oréal Paris','L’Oreal Paris');add_brand("Momo's Workshop",'Momos Workshop','Momo’s Workshop')
for name in ['Ipek','Dinto','Kissme','ZA','Browit','Baby Bright','Cathy Doll','CM24',"Momo's Brushery",'Byphasse','Caudalie','Christophe Robin','Cocayhoala','Le Petit Marseillais','Batiste','Colab','Gota','Beplain','Elastine','Boya','Keumyon','Dyson',"Kiehl's",'Laboratorios BABE','Neutrogena','Nature Republic','Kiss My Body','Black Rouge','Too Cool For School','Biaeffect','Emmié','Bano:Bagi','Mine','Diesel','Salvatore Ferragamo','Cacharel','Gennie','De Memoria','Garnier','Mlen Diary','Keyshu','Cosrx','Sugarplum','Beautylabo','Juno','SVR','ASEPSO','Ever Collagen','Got2b','Jane','Femfresh','Evian']:
 add_brand(name)
add_brand('LIP IT','Lipit');add_brand('D Program','DProgram');add_brand("Momo's Workshop","Momo's Wordshop");add_brand("L'Oreal",'L’Oreal','Loreal')
add_brand('THE FACE SHOP','Yehwadam')

brand_pages={};brand_countries={};brand_evidence={};brand_ids={}
COUNTRY_WORDS={'Hàn Quốc':'Hàn Quốc','Nhật Bản':'Nhật Bản','Pháp':'Pháp','Mỹ':'Mỹ','Hoa Kỳ':'Mỹ','Việt Nam':'Việt Nam','Anh Quốc':'Anh','Thụy Sĩ':'Thụy Sĩ','Đài Loan':'Đài Loan','Trung Quốc':'Trung Quốc','Thái Lan':'Thái Lan','Ý':'Ý','Đức':'Đức','Úc':'Úc','Canada':'Canada','Tây Ban Nha':'Tây Ban Nha','Nga':'Nga'}
reviewed_countries={'AESTURA':'Hàn Quốc','AHC':'Hàn Quốc','AMUSE':'Hàn Quốc','AVÈNE':'Pháp','BEYOND':'Hàn Quốc','BIODERMA':'Pháp','CLUB CLIO':'Hàn Quốc','COCOON':'Việt Nam','DEAR DAHLIA':'Hàn Quốc','ELIXIR':'Nhật Bản','GLINT':'Hàn Quốc','GOODAL':'Hàn Quốc','KLAVUU':'Hàn Quốc','LA ROCHE-POSAY':'Pháp','MISE EN SCENE':'Hàn Quốc','OHUI':'Hàn Quốc',"PAULA'S CHOICE":'Mỹ','PAYOT':'Pháp','SKINFOOD':'Hàn Quốc'}
reviewed_countries.update({'THE FACE SHOP':'Hàn Quốc','SU:M37°':'Hàn Quốc','3CE':'Hàn Quốc'})
for path in (B/'brand_live').glob('*.json.gz'):
 x=json.loads(gzip.decompress(path.read_bytes()));p=x.get('collection') or {};name=x['brand'];desc=text_html(detail(p).get('htmlDescription'))
 add_brand(name)
 brand_pages[norm(name)]=x
 if p.get('id'):brand_ids[str(p['id'])]=name
 if name in reviewed_countries and reviewed_countries[name] in desc:
  brand_countries[norm(name)]=reviewed_countries[name];brand_evidence[norm(name)]=x['url']
for child in ('CLIO','PERIPERA','DERMATORY'):
 if norm('CLUB CLIO') in brand_countries:brand_countries[norm(child)]='Hàn Quốc';brand_evidence[norm(child)]=brand_evidence[norm('CLUB CLIO')]
brand_countries[norm('Tangle Teezer')]='Anh'
brand_evidence[norm('Tangle Teezer')]='https://beautybox.com.vn/products/luoc-tangle-teezer-tud-fine-fragile-go-roi-toi-uu-cho-toc-mong-va-de-gay'

patterns={
 'G':r'(?:xuất xứ thương hiệu|nguồn gốc thương hiệu|quốc gia thương hiệu)',
 'H':r'(?:đối tượng(?: sử dụng| phù hợp)?|loại da(?: phù hợp| sử dụng)?|làn da(?: sử dụng| phù hợp)?|da phù hợp|loại tóc(?: phù hợp)?|phù hợp(?: với)?|dành cho)',
 'J':r'(?:dung tích|khối lượng(?: tịnh)?|trọng lượng(?: tịnh)?|quy cách(?: đóng gói)?|thể tích)',
 'K':r'(?:công dụng(?: chính| nổi bật)?|tác dụng(?: chính)?|lợi ích(?: chính)?|ưu điểm(?: nổi bật)?|đặc điểm nổi bật|tính năng(?: nổi bật)?|hiệu quả sử dụng)',
 'L':r'(?:thành phần(?: chính| nổi bật| đầy đủ| hoạt tính| nổi trội| tự nhiên)?|bảng thành phần|full ingredients|ingredients)'
}
stop_heading=re.compile(r'^(?:'+ '|'.join(patterns.values())+r'|hướng dẫn(?: sử dụng)?|cách (?:dùng|sử dụng)|lưu ý|bảo quản|thông tin(?: sản phẩm| thương hiệu)?|thương hiệu|xuất xứ|nơi sản xuất|sản xuất tại|hạn sử dụng|bảng màu|giới thiệu|mùi hương|đặc tính|kết cấu)(?:\s*[:：]|\s*$)',re.I)

def section(text,col):
 lines=text.splitlines();pattern=re.compile(r'^\s*(?:\d+[.)]\s*)?'+patterns[col]+r'(?:\s+của[^:：]{0,160})?\s*(?::|：|$)',re.I)
 for i,line in enumerate(lines):
  clean=re.sub(r'^[\s*•\-]+','',line);m=pattern.match(clean)
  if not m:continue
  out=[clean[m.end():].strip()]
  for nextline in lines[i+1:i+55]:
   if stop_heading.match(nextline.strip()):break
   if len('\n'.join(out))+len(nextline)>5000:break
   out.append(nextline.strip())
  result='\n'.join(x for x in out if x).strip()
  if result:
   if col=='J':return ' + '.join(sizes(result,True)) or None
   if col=='G':
    hits=unique(v for k,v in COUNTRY_WORDS.items() if re.search(r'(?<!\w)'+re.escape(k)+r'(?!\w)',result))
    return hits[0] if len(hits)==1 else None
   if col=='H':
    # Avoid pulling later marketing paragraphs into an audience field.
    return '\n'.join(result.splitlines()[:5])[:500]
   return result
 return None

def target(text):
 v=section(text,'H')
 if v:return v
 for line in text.splitlines():
  if re.search(r'(?:phù hợp|thích hợp|dành)\s+(?:với|cho)',line,re.I):
   m=re.search(r'(?:phù hợp|thích hợp|dành)\s+(?:với|cho)\s+(.{2,240})',line,re.I)
   if m:
    value=re.split(r'[.!?;]|(?:,\s*(?:giúp|mang lại|với |sản phẩm))',m.group(1))[0].strip(' ,:-')
    if re.search(r'\b(?:da|tóc|nam|nữ|trẻ em|người)\b',value,re.I):return value[0].upper()+value[1:]
 skin=r'(?:mọi loại da|mọi làn da|da thường|da khô(?: đến rất khô)?|da dầu(?: mụn)?|da hỗn hợp(?: thiên dầu| thiên khô)?|da nhạy cảm|da mụn|da dễ kích ứng|da lão hóa|da xỉn màu|da mất nước|tóc nhuộm|tóc khô xơ|tóc hư tổn|tóc mỏng|tóc dễ gãy rụng)'
 explicit=re.search(r'(?:dành cho|cho|phù hợp với)\s+('+skin+r'(?:\s*(?:,|và|hoặc)\s*'+skin+r')*)',text,re.I)
 if explicit:return explicit.group(1)
 hair=re.search(r'(?:phục hồi|chăm sóc|nuôi dưỡng)\s+(tóc\s+[^.!?\n]{3,180})',text,re.I)
 if hair and re.search(r'khô|yếu|hư tổn|nhuộm|chẻ ngọn|dễ gãy',hair.group(1),re.I):return hair.group(1)
 return None

def benefit(text):
 v=section(text,'K')
 if v:return v
 sentences=re.split(r'(?<=[.!?])\s+|\n',text)
 result=[]
 for line in sentences:
  if len(line)>700 or len(line)<15:continue
  if re.search(r'\b(?:giúp|hỗ trợ|mang lại|làm sạch|dưỡng ẩm|cấp ẩm|bảo vệ da|che phủ|kiềm dầu|lâu trôi|làm dịu|phục hồi|làm sáng|làm mịn|cấp nước|tăng cường|hydrat hóa|tái tạo|làm khỏe|se khít)\b',line,re.I) and not re.search(r'^(?:cách|hướng dẫn|lưu ý|bảo quản)',line,re.I):result.append(line)
  if len(result)==3:break
 return '\n'.join(result) or None

def ingredients(text,materials=False):
 v=section(text,'L')
 if v:return v
 result=[]
 for line in re.split(r'(?<=[.!?])\s+|\n',text):
  if 15<=len(line)<=700 and re.search(r'\b(?:chiết xuất|thành phần|chứa|bổ sung|kết hợp giữa)\b',line,re.I) and not re.search(r'không chứa|không sử dụng|lưu ý|nếu có|tránh',line,re.I):result.append(line)
  if len(result)==3:break
 if not result and materials:
  for line in re.split(r'(?<=[.!?])\s+|\n',text):
   if 10<=len(line)<=700 and re.search(r'(?:được )?làm từ|chất liệu|100%\s*(?:cotton|bông|polyester)',line,re.I):result.append(line)
   if len(result)==3:break
 return '\n'.join(result) or None

def common_description(desc,p):
 relevant={'2356568396','2628576619','2430201900','2479789507'}
 labels=unique(norm(re.sub(r'^\d+[.)_\-]?\s*','',attribute_text(a))) for v in p.get('variants') or [] for a in flatten_attrs(v.get('attributeValues')) if str(a.get('attributeId')) in relevant and not sizes(attribute_text(a),True) and norm(attribute_text(a)) not in ('default title','mau moi','ver basic','co ban'))
 if len(labels)<2:return desc
 lines=desc.splitlines()
 for i,line in enumerate(lines):
  h=re.sub(r'^\s*(?:[-*•]\s*)?(?:\d{1,2}[.)]?\s+)?','',line).strip();n=norm(h)
  for label in labels:
   if n==label or (n.startswith(label+' ') and re.search(r'[:：–—&(-]',h[:len(label)+7])):return '\n'.join(lines[:i])
 return desc

def identify_brand(title,description=''):
 t=' '+norm(title)+' '
 matches=[(len(alias),canonical) for alias,canonical in ALIASES.items() if ' '+alias+' ' in t]
 if matches:return max(matches)[1]
 return None

changes=[];size_conflicts=[];specific_blocks=[];missing_match=[];withheld=[]
def put(row,col,value,source,method):
 if row.get(col) not in (None,'') or value in (None,''):return
 value=str(value).strip()
 if not value or len(value)>32767:return
 row[col]=value;changes.append({'cell':f'{col}{row["row"]}','row':row['row'],'product_id':str(row['C']),'sku':str(row.get('D')),'column':col,'value':value,'source':source,'method':method})

parents={str(r['C']):r for r in rows if r.get('B')=='Sản phẩm'}
contexts={}
for pid,r in parents.items():
 source=r['O'];snapshot=live.get(pid,{});p=snapshot.get('raw_product') or old.get(pid) or catalog.get(pid) or {};fallback=old.get(pid) or catalog.get(pid) or {}
 d=detail(p);desc=text_html(d.get('htmlDescription')) or text_html(detail(fallback).get('htmlDescription')) or r.get('M') or ''
 title=d.get('name') or (p.get('graphData') or {}).get('title') or r['E']
 brand=snapshot.get('brand_text') or identify_brand(title,desc)
 if not brand:
  membership=unique(brand_ids[str(x)] for x in p.get('collections') or [] if str(x) in brand_ids)
  if len(membership)==1:brand=membership[0]
 put(r,'F',brand,source,'public_brand_or_explicit_title')
 country=section(desc,'G');country_source=source
 if not country:
  country=brand_countries.get(norm(r.get('F') or brand));country_source=brand_evidence.get(norm(r.get('F') or brand),source)
 put(r,'G',country,country_source,'explicit_brand_country')
 common=common_description(desc,p)
 audience=target(title) or target(common)
 if re.search(r'\b(?:nước hoa|nước thơm|vệ sinh|dầu gội|sữa tắm)\b',title,re.I):
  gender=re.search(r'\b(nam|nữ|trẻ em)\b',title,re.I)
  if gender:audience=gender.group(1).capitalize()
 put(r,'H',audience,source,'explicit_target_text')
 size=section(desc,'J') or ' + '.join(sizes(title,True))
 if not size:
  choices=unique(s for v in (p.get('variants') or []) for a in flatten_attrs(v.get('attributeValues')) if str(a.get('attributeId'))!='2628576621' for s in sizes(attribute_text(a),True))
  size=' / '.join(choices)
 put(r,'J',size,source,'explicit_size')
 put(r,'K',benefit(common),source,'explicit_benefit_text')
 material_category=bool(re.search(r'bông cotton|mút trang điểm|cọ trang điểm|móc khóa|đèn|lược|phụ kiện|gối|nhồi bông',r.get('A',''),re.I))
 put(r,'L',ingredients(common,material_category),source,'explicit_ingredient_text')
 put(r,'M',desc or (p.get('graphData') or {}).get('description'),source,'public_description')
 images=snapshot.get('image_urls') or [];thumbnail=p.get('thumbnail') or (p.get('graphData') or {}).get('thumbnail')
 image=images[0] if images else ('https://image.hsv-tech.io/600x600/'+thumbnail.lstrip('/') if thumbnail and thumbnail.startswith('bbx/') else thumbnail)
 if image and image.startswith('https://'):put(r,'N',image,source,'public_product_image')
 contexts[pid]={'p':p,'fallback':fallback,'desc':desc,'source':source}

def variant_block(desc,v,p):
 relevant={'2356568396','2628576619','2430201900','2479789507'}
 selected=[a for a in flatten_attrs(v.get('attributeValues')) if str(a.get('attributeId')) in relevant]
 def aliases(a):
  s=attribute_text(a)
  if norm(s) in ('default title','mau moi','ver basic','co ban'):return []
  without_size=re.sub(r'\d+(?:[.,]\d+)?\s*(?:ml|kg|g|l|miếng|pcs)\b','',s,flags=re.I).strip(' -')
  if not norm(without_size):return []
  parts=[s,without_size,re.split(r'\s+[-–—]\s+',without_size)[0],re.sub(r'^\d+[.)_\-]?\s*','',without_size)]+re.findall(r'\(([^)]+)\)',s)
  return unique(norm(x) for x in parts if len(norm(x))>=4)
 labels=unique(x for a in selected for x in aliases(a))
 if not labels:return None
 others=unique(x for vv in p.get('variants') or [] for a in flatten_attrs(vv.get('attributeValues')) if str(a.get('attributeId')) in relevant for x in aliases(a) if x not in labels)
 if not others:return None
 lines=desc.splitlines();normalized=[norm(x) for x in lines]
 def contains(s,label):return ' '+label+' ' in ' '+s+' '
 for i,n in enumerate(normalized):
  if len(lines[i])>240 or not any(contains(n,label) for label in labels):continue
  if any(contains(n,x) for x in others):continue
  # Percentages and ingredient bullets are not variant headings.
  heading=re.sub(r'^\s*\d{1,2}[.)]?\s+','',lines[i]).strip()
  hn=norm(heading)
  matched_labels=[label for label in labels if hn==label or (hn.startswith(label+' ') and (':' in heading[:len(label)+5] or re.search(r'[-–—(&]',heading[:len(label)+6])))]
  if not matched_labels:continue
  end=min(len(lines),i+45)
  for j in range(i+1,end):
   if len(lines[j])<240 and any(contains(normalized[j],x) for x in others):end=j;break
   if re.match(r'^(?:hướng dẫn|cách sử dụng|cách dùng|lưu ý|bảo quản)',lines[j],re.I):end=j;break
   if stop_heading.match(lines[j].strip()) and not re.match(r'^'+patterns['H']+r'\s*[:：]\s*\S',lines[j],re.I):end=j;break
   if re.match(r'^\s*\d{1,2}[.)]?\s+[^\n]{2,100}[:–—]',lines[j]):end=j;break
   if re.match(r'^\s*\d{1,2}[.)]\s+',lines[j]):end=j;break
   if re.match(r'^\s*[-*•]\s*[A-Za-z][^:：]{1,100}[:：]',lines[j]):end=j;break
  block='\n'.join(lines[i:end]).strip()
  if len(block)>len(lines[i])+10 or ':' in lines[i] or re.search(r'giúp|dưỡng|chiết xuất|thành phần',block,re.I):return block
 return None

for r in rows:
 if r.get('B')!='Biến thể':continue
 pid=str(r['C']);parent=parents[pid];context=contexts[pid];p=context['p'];source=r.get('O') or context['source']
 candidates=[v for v in p.get('variants') or [] if str(v.get('sku'))==str(r.get('D'))]
 using_old=False
 if len(candidates)!=1:
  candidates=[v for v in context['fallback'].get('variants') or [] if str(v.get('sku'))==str(r.get('D'))];using_old=True
 v=candidates[0] if len(candidates)==1 else None
 if v is None:missing_match.append({'row':r['row'],'product_id':pid,'sku':r['D']})
 if v:
  attrs=list(flatten_attrs(v.get('attributeValues')))
  size_values=unique(s for a in attrs if str(a.get('attributeId'))!='2628576621' for s in sizes(attribute_text(a),True))
  all_sizes=unique(s for vv in p.get('variants') or [] for a in flatten_attrs(vv.get('attributeValues')) if str(a.get('attributeId'))!='2628576621' for s in sizes(attribute_text(a),True))
  parent_sizes=sizes(parent.get('J') or '',True)
  size=' + '.join(size_values)
  quantity_only=bool(size_values) and all(re.search(r'(?:miếng|pcs)$',x) for x in size_values)
  if size and parent_sizes and set(size_values)!=set(parent_sizes) and len(all_sizes)==1 and not quantity_only:
   size_conflicts.append({'row':r['row'],'product_id':pid,'name':r['E'],'parent':parent['J'],'variant':size,'sku':r['D'],'url':source})
   size=None
  put(r,'J',size,source,'matched_variant_attribute')
  block=variant_block(context['desc'],v,p)
  if block:
   specific_blocks.append({'row':r['row'],'sku':r['D'],'product_id':pid,'block':block})
   put(r,'H',target(block),source,'matched_variant_description')
   if not r.get('H'):
    match=re.search(r'(?:[-–—:]\s*)((?:da|làn da)\s+[^\n]{3,150})',block,re.I)
    if match:put(r,'H',match.group(1),source,'matched_variant_target_label')
   put(r,'K',benefit(block),source,'matched_variant_description')
   put(r,'L',ingredients(block),source,'matched_variant_description')
   if not r.get('L'):
    names=r'PDRN|Niacinamide|Collagen|Hyaluronic|Glycerin|Vitamin|Retinal|Retinol|Peptide|BHA|AHA|Ceramide|Panthenol|Centella'
    components=[line for line in block.splitlines()[1:] if re.match(r'^(?:'+names+r')\b',line,re.I)]
    put(r,'L','\n'.join(components[:3]),source,'matched_variant_ingredient_sentence')
   put(r,'M',block,source,'matched_variant_description')
  # Ingredient option labels are explicit per-variant product attributes.
  ingredient_options=unique(attribute_text(a) for a in attrs if str(a.get('attributeId'))=='2356568396')
  put(r,'L','; '.join(ingredient_options),source,'matched_variant_ingredient_option')
  thumbnail=v.get('thumbnail')
  if thumbnail:
   image='https://image.hsv-tech.io/600x600/'+thumbnail.lstrip('/') if thumbnail.startswith('bbx/') else thumbnail
   if image.startswith('https://'):put(r,'P',image,source,'matched_variant_image')
 # Prefer the exact variant's image for its image cell.
 put(r,'N',r.get('P'),source,'exact_variant_image')
 for col in ['F','G','H','J','K','L','M','N']:
  if v and col in ('H','K','L') and not r.get(col) and parent.get(col):
   def named_options(vv):
    return unique(norm(attribute_text(a)) for a in flatten_attrs(vv.get('attributeValues')) if str(a.get('attributeId')) in {'2356568396','2628576619','2430201900','2479789507'} and not sizes(attribute_text(a),True) and norm(attribute_text(a)) not in ('default title','mau moi','ver basic','co ban'))
   own=named_options(v);others=unique(x for vv in p.get('variants') or [] for x in named_options(vv) if x not in own and len(x.split())>=2)
   value=' '+norm(parent[col])+' '
   if any(' '+x+' ' in value for x in others) and not any(' '+x+' ' in value for x in own):
    withheld.append({'cell':f'{col}{r["row"]}','reason':'Parent text explicitly names a different variant','source':source});continue
  put(r,col,parent.get(col),parent.get('O'),f'parent_fallback:{parent["row"]}')
 put(r,'P',parent.get('N'),parent.get('O'),f'parent_image_fallback:{parent["row"]}')

summary={'products':len(parents),'variants':sum(r.get('B')=='Biến thể' for r in rows),'live_pages':len(live),'new_cells':len(changes),'by_column':dict(collections.Counter(c['column'] for c in changes)),'by_method':dict(collections.Counter(c['method'].split(':')[0] for c in changes)),'remaining_blanks':{kind:{col:sum(not r.get(col) for r in rows if r.get('B')==kind) for col in ['F','G','H','J','K','L','M','N','P']} for kind in ['Sản phẩm','Biến thể']}}
for name,obj in [('filled_rows.json',rows),('changes.json',changes),('summary.json',summary),('size_conflicts.json',size_conflicts),('variant_blocks.json',specific_blocks),('unmatched_variants.json',missing_match),('withheld.json',withheld)]:
 (B/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
(B/'unknown_brand_titles.json').write_text(json.dumps([{'row':r['row'],'name':r['E']} for r in rows if r.get('B')=='Sản phẩm' and not r.get('F')],ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False));print('size_conflicts',len(size_conflicts),'variant_blocks',len(specific_blocks),'unmatched_variants',len(missing_match))
