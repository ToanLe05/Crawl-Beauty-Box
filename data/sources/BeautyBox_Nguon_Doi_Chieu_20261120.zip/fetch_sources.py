import concurrent.futures,gzip,json,pathlib,re,threading,time,urllib.request,urllib.error,sys
from datetime import datetime,timezone
from lxml import html

BASE=pathlib.Path('/tmp/beautybox_enrich_4428')
CACHE=BASE/'live';CACHE.mkdir(exist_ok=True)
ROWS=json.loads((BASE/'rows.json').read_text())
PRODUCTS=[r for r in ROWS if r.get('B')=='Sản phẩm']
PRODUCTS.sort(key=lambda r:(bool(r.get('M')),bool(r.get('F')),r['row']))
REVERSE='--reverse' in sys.argv
if REVERSE:PRODUCTS.reverse()
stop=threading.Event();lock=threading.Lock();last=[0.0]
HEADERS={'User-Agent':'BeautyBoxDatasetResearch/1.0','Accept-Language':'vi-VN,vi;q=0.9','Accept':'text/html'}

def request(url):
    with lock:
        pause=max(0,0.65-(time.monotonic()-last[0]))
        if pause:time.sleep(pause)
        last[0]=time.monotonic()
    if stop.is_set():raise RuntimeError('Stopped after access/rate-limit response')
    req=urllib.request.Request(url,headers=HEADERS)
    with urllib.request.urlopen(req,timeout=30) as res:
        return res.read(),res.geturl(),res.status

def get_state(tree):
    nodes=tree.xpath('//script[@id="__NEXT_DATA__"]/text()')
    if not nodes:raise ValueError('Missing public page data')
    return json.loads(nodes[0]).get('props',{}).get('pageProps',{}).get('initialReduxState',{})

def dump(path,value):
    tmp=path.with_name(path.name+f'.{threading.get_ident()}.tmp')
    tmp.write_bytes(gzip.compress(json.dumps(value,ensure_ascii=False).encode(),compresslevel=5));tmp.replace(path)

def fetch_one(row):
    pid=str(row['C']);url=row['O'];path=CACHE/(pid+'.json.gz')
    if path.exists():return json.loads(gzip.decompress(path.read_bytes()))
    result={'product_id':pid,'source_url':url,'fetched_at_utc':datetime.now(timezone.utc).isoformat()}
    try:
        for attempt in range(2):
            try:data,final,status=request(url);break
            except urllib.error.HTTPError as e:
                if e.code in (401,403,429):stop.set();raise
                if e.code not in (500,502,503,504) or attempt:raise
                time.sleep(2)
        tree=html.fromstring(data);state=get_state(tree)
        queries=state.get('productsApi',{}).get('queries',{})
        p=next((x.get('data') for k,x in queries.items() if k.startswith('getByIdProducts(') and isinstance(x.get('data'),dict)),None)
        if not p:raise ValueError('No product details in response')
        if str(p.get('id'))!=pid:raise ValueError('Product ID mismatch: '+str(p.get('id')))
        brands=[e.text_content().strip() for e in tree.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," brand-name ")]') if e.text_content().strip()]
        media=[m.get('url') for m in p.get('medias') or [] if m.get('url')]
        image_urls=list(dict.fromkeys(u for u in tree.xpath('//img/@src') if any(m in u for m in media)))
        result.update(status='ok',http_status=status,final_url=final,brand_text=brands[0] if brands else None,raw_product=p,image_urls=image_urls)
        # Public CMS menu brand names help match explicitly named brands in titles.
        menu=[]
        def walk(x):
            if isinstance(x,dict):
                if x.get('name') and x.get('path'):menu.append({'name':x['name'],'path':x['path']})
                for v in x.values():walk(v)
            elif isinstance(x,list):
                for v in x:walk(v)
        for key,value in state.get('cmsApi',{}).get('queries',{}).items():
            if '/headerMenus/bottom' in key:walk(value.get('data'))
        result['menu_links']=menu
    except Exception as e:
        result.update(status='error',error=str(e),error_type=type(e).__name__)
    dump(path,result)
    return result

def main():
    if not (BASE/'brands.html.gz').exists():
        try:
            data,url,status=request('https://beautybox.com.vn/brands')
            (BASE/'brands.html.gz').write_bytes(gzip.compress(data))
            state=get_state(html.fromstring(data));dump(BASE/'brands_state.json.gz',state)
            print(json.dumps({'brands_page':status,'bytes':len(data)}),flush=True)
        except Exception as e:print(json.dumps({'brands_error':str(e)}),flush=True)
    results=[];started=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures={pool.submit(fetch_one,r):r for r in PRODUCTS}
        for f in concurrent.futures.as_completed(futures):
            res=f.result();results.append({k:v for k,v in res.items() if k not in ('raw_product','menu_links','image_urls')})
            if len(results)%25==0 or len(results)==len(PRODUCTS):
                index={'checked':len(results),'total':len(PRODUCTS),'ok':sum(r['status']=='ok' for r in results),'errors':sum(r['status']!='ok' for r in results),'elapsed_seconds':round(time.monotonic()-started),'stopped':stop.is_set(),'results':results}
                (BASE/('fetch_status_reverse.json' if REVERSE else 'fetch_status.json')).write_text(json.dumps(index,ensure_ascii=False))
                print(json.dumps({k:v for k,v in index.items() if k!='results'}),flush=True)
    print(json.dumps({'finished':True,'stopped':stop.is_set()}),flush=True)

if __name__=='__main__':main()
