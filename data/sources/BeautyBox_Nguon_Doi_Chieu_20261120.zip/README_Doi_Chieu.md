# Nguồn đối chiếu và các ô đã bổ sung

Đã đọc lại 1.130 URL sản phẩm Beauty Box ngày 20/11/2026. Mỗi trang được kiểm tra theo ID sản phẩm; biến thể được ghép theo SKU trong cùng sản phẩm.

- `live/`: dữ liệu công khai đọc từ từng trang, có URL và thời gian UTC.
- `brand_live/`: trang giới thiệu thương hiệu dùng để xác minh xuất xứ thương hiệu.
- `changes.json`: từng ô được bổ sung, giá trị, URL nguồn và cách lấy dữ liệu.
- `size_conflicts.json`: chênh lệch giữa dung tích của sản phẩm gốc và thuộc tính biến thể; các giá trị mâu thuẫn không được coi là thông tin riêng đã xác minh.
- `withheld.json`: các trường không sao chép vì nội dung của sản phẩm gốc chỉ rõ một biến thể khác.
- `rows.json`, `raw.json`: dữ liệu trước khi bổ sung và JSON crawl có trong file đầu vào.

Chỉ điền ô trống. Ưu tiên thuộc tính và nội dung riêng của biến thể; phần còn thiếu dùng thông tin từ sản phẩm gốc khi phù hợp. Xuất xứ sản phẩm không được tự coi là xuất xứ thương hiệu. Các ô thiếu nguồn đáng tin cậy được để trống. Cột URL ảnh biến thể không áp dụng cho dòng sản phẩm gốc.
