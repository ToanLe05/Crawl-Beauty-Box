"""Preserve the input XLSX package; merge only requested Artifact Tool cell edits."""
import copy,gzip,json,pathlib,zipfile,collections
from lxml import etree as E

B=pathlib.Path('/tmp/beautybox_enrich_4428');ROOT=pathlib.Path('/workspace/scratch/4428dc43481c')
SOURCE=ROOT/'outputs/beautybox_note_retry_4428/em_iu_beautybox.xlsx'
AUTHORED=B/'authored.xlsx';FINAL=ROOT/'outputs/beautybox_enriched_4428/em_iu_beautybox_bo_sung.xlsx'
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
changes=json.loads((B/'changes.json').read_text());expected={x['cell']:x['value'] for x in changes}
assert len(expected)==len(changes),'Duplicate cell changes'
baseline=json.loads((B/'rows.json').read_text());filled=json.loads((B/'filled_rows.json').read_text())
assert len(baseline)==len(filled)==3794
for a,b in zip(baseline,filled):
 assert a['row']==b['row']
 for col,v in a.items():
  if col!='row' and v not in (None,''):assert b.get(col)==v,('Overwrote nonblank input',col,a['row'])
 for col,v in b.items():
  if v!=a.get(col):assert f'{col}{b["row"]}' in expected
for c in changes:
 assert c['column'] in ['F','G','H','J','K','L','M','N','P']
 assert c['source'].startswith('https://')
 assert not c['value'].startswith('=')
 if c['column'] in ('N','P'):assert c['value'].startswith('https://')

class Book:
 def __init__(self,path):
  self.z=zipfile.ZipFile(path);self.ss=[]
  if 'xl/sharedStrings.xml' in self.z.namelist():
   self.ss=[''.join(x.text or '' for x in item.iter(M+'t')) for item in E.fromstring(self.z.read('xl/sharedStrings.xml'))]
 def val(self,c):
  if c is None:return None
  t=c.get('t');v=c.find(M+'v')
  if t=='s':return self.ss[int(v.text)]
  if t=='inlineStr':return ''.join(x.text or '' for x in c.iter(M+'t')) or None
  if v is None:return None
  if t in ('str','e'):return v.text or None
  if t=='b':return v.text=='1'
  try:return float(v.text)
  except:return v.text

src=Book(SOURCE);auth=Book(AUTHORED);part='xl/worksheets/sheet2.xml'
original=E.fromstring(src.z.read(part));edited=E.fromstring(auth.z.read(part))
old_cells={c.get('r'):c for c in original.findall(M+'sheetData/'+M+'row/'+M+'c')}
new_cells={c.get('r'):c for c in edited.findall(M+'sheetData/'+M+'row/'+M+'c')}
for addr,value in expected.items():
 assert addr in old_cells,('Unexpected new cell',addr)
 assert src.val(old_cells[addr]) in (None,''),('Cell was not blank',addr)
 assert auth.val(new_cells.get(addr))==value,('Artifact output differs',addr)
 old=old_cells[addr];new=new_cells[addr]
 for c in list(old):
  if c.tag in (M+'v',M+'is',M+'f'):old.remove(c)
 old.attrib.pop('t',None)
 if new.get('t')=='s':
  old.set('t','inlineStr');inline=E.SubElement(old,M+'is');text=E.SubElement(inline,M+'t');text.text=auth.val(new)
 else:
  if new.get('t'):old.set('t',new.get('t'))
  for c in new:
   if c.tag in (M+'v',M+'is',M+'f'):old.append(copy.deepcopy(c))

xml=E.tostring(original,encoding='utf-8',xml_declaration=True,standalone=True)
with zipfile.ZipFile(FINAL,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for info in src.z.infolist():out.writestr(copy.copy(info),xml if info.filename==part else src.z.read(info.filename))
final=Book(FINAL)
assert final.z.testzip() is None
for name in src.z.namelist():
 if name!=part:assert src.z.read(name)==final.z.read(name),('Unrelated package member changed',name)
result=E.fromstring(final.z.read(part));final_cells={c.get('r'):c for c in result.findall(M+'sheetData/'+M+'row/'+M+'c')}
for addr,c in old_cells.items():
 assert final.val(final_cells.get(addr))== (expected[addr] if addr in expected else src.val(c)),('Final data mismatch',addr)
for addr,value in expected.items():assert final.val(final_cells[addr])==value
parent_order=[r['C'] for r in baseline if r['B']=='Sản phẩm'];assert parent_order==[r['C'] for r in filled if r['B']=='Sản phẩm']
active_pid=None
for r in filled:
 if r['B']=='Sản phẩm':active_pid=r['C']
 else:assert r['C']==active_pid,('Variant detached from parent',r['row'])
cached=[json.loads(gzip.decompress(p.read_bytes())) for p in (B/'live').glob('*.json.gz')]
assert len(cached)==1130,'Incomplete source URL attempts'
summary=json.loads((B/'summary.json').read_text());summary['validation']={'only_blank_cells_filled':True,'existing_values_preserved':True,'all_other_workbook_parts_byte_identical':True,'products_and_variants_kept_together':True,'source_urls_attempted':len(cached),'source_urls_read_live':sum(x['status']=='ok' for x in cached),'file_bytes':FINAL.stat().st_size}
(FINAL.parent/'completion_report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({'output':str(FINAL),'new_cells':len(expected),'validation':summary['validation']},ensure_ascii=False))
