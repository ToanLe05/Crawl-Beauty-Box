"""One bounded retry of transport failures, without changing host or access method."""
import concurrent.futures,gzip,json,pathlib
import fetch_sources as f
B=pathlib.Path('/tmp/beautybox_enrich_4428');eligible=[]
for row in f.PRODUCTS:
 path=f.CACHE/(str(row['C'])+'.json.gz')
 if not path.exists():continue
 result=json.loads(gzip.decompress(path.read_bytes()))
 if result.get('status')=='error' and result.get('error_type') in ('URLError','IncompleteRead','TimeoutError'):
  path.replace(path.with_name(path.name+'.first_error'));eligible.append(row)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(f.fetch_one,eligible))
print(json.dumps({'transport_retries':len(eligible),'recovered':sum(r['status']=='ok' for r in results),'still_unavailable':sum(r['status']!='ok' for r in results)}),flush=True)
