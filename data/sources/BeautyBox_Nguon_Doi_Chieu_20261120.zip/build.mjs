import fs from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';

const base='/tmp/beautybox_enrich_4428';
const root='/workspace/scratch/4428dc43481c';
const input=`${root}/outputs/beautybox_note_retry_4428/em_iu_beautybox.xlsx`;
const outputDir=`${root}/outputs/beautybox_enriched_4428`;
const phase=process.argv[2]??'preview';
try {
 const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(input));
 const sh=wb.worksheets.getItem('Tất cả');
 if(phase==='preview') {
  const png=await wb.render({sheetName:'Tất cả',range:'E6:L11',scale:1,format:'png'});
  await fs.writeFile(`${outputDir}/before.png`,new Uint8Array(await png.arrayBuffer()));
  console.log(JSON.stringify({preview:`${outputDir}/before.png`}));
 } else {
  const rows=JSON.parse(await fs.readFile(`${base}/filled_rows.json`,'utf8'));
  const changes=JSON.parse(await fs.readFile(`${base}/changes.json`,'utf8'));
  const columns=[...new Set(changes.map(c=>c.column))];
  for(const col of columns) sh.getRange(`${col}7:${col}3800`).values=rows.map(r=>[r[col]??null]);
  wb.recalculate();
  console.log((await wb.inspect({kind:'table',range:"'Tất cả'!F188:L192",include:'values,formulas',tableMaxRows:5,tableMaxCols:7,tableMaxCellChars:100,maxChars:2400})).ndjson);
  console.log((await wb.inspect({kind:'match',sheetId:'Tất cả',range:'A6:P3800',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:1000})).ndjson);
  for(const [name,range] of [['after','E6:L11'],['variant_detail','H189:M192'],['variant_sizes','E375:L379']]) {
   const png=await wb.render({sheetName:'Tất cả',range,scale:1,format:'png'});
   await fs.writeFile(`${outputDir}/${name}.png`,new Uint8Array(await png.arrayBuffer()));
  }
  const out=await SpreadsheetFile.exportXlsx(wb);await out.save(`${base}/authored.xlsx`);
  console.log(execFileSync(process.env.CODEX_PRIMARY_RUNTIME_PYTHON,[`${base}/preserve_and_validate.py`],{encoding:'utf8'}));
 }
} catch(e){console.error(e.message);console.error(e.stack?.split('\n').slice(-4).join('\n'));process.exitCode=1;}
