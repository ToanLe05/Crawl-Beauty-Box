import concurrent.futures,gzip,json,pathlib,time,urllib.request,threading
from lxml import html

B=pathlib.Path('/tmp/beautybox_enrich_4428');D=B/'brand_live';D.mkdir(exist_ok=True)
t=html.fromstring(gzip.decompress((B/'brands.html.gz').read_bytes()))
links=list(dict.fromkeys((x.get('href').strip(),x.text_content().strip()) for x in t.xpath('//a[contains(@href,"/collections/")]') if x.text_content().strip() and x.text_content().strip()!='Sản Phẩm Mới'))
lock=threading.Lock();last=[0.0]
def fetch(item):
 path,name=item;slug=path.rsplit('/',1)[-1];f=D/(slug+'.json.gz')
 if f.exists():return
 result={'brand':name,'url':'https://beautybox.com.vn'+path}
 try:
  with lock:
   pause=max(0,0.8-(time.monotonic()-last[0]))
   if pause:time.sleep(pause)
   last[0]=time.monotonic()
  with urllib.request.urlopen(urllib.request.Request(result['url'],headers={'User-Agent':'BeautyBoxDatasetResearch/1.0'}),timeout=30) as r:data=r.read()
  tree=html.fromstring(data);state=json.loads(tree.xpath('//script[@id="__NEXT_DATA__"]/text()')[0])['props']['pageProps']['initialReduxState']
  q=state.get('productCollectionsApi',{}).get('queries',{})
  collection=next((v.get('data') for k,v in q.items() if k.startswith('getByIdProductCollections(')),None)
  result.update(status='ok',collection=collection)
 except Exception as e:result.update(status='error',error=str(e))
 f.write_bytes(gzip.compress(json.dumps(result,ensure_ascii=False).encode()))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(fetch,links))
print(json.dumps({'brands_checked':len(links)}),flush=True)
